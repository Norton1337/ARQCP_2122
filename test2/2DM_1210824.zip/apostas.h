#ifndef APOSTAS_H
#define APOSTAS_H
int apostas_premiadas(unsigned int *apostas, int n, unsigned int chave_sorteada, unsigned char *premiadas);
#endif
