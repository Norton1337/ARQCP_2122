#ifndef VERIFICA_H
#define VERIFICA_H
int verifica_aposta(unsigned int aposta, unsigned int chave_sorteada);
#endif
