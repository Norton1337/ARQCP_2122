#include "utility.h"
#ifndef PRINT_ARRAY_H
#define PRINT_ARRAY_H
void printArray(int arr[]);
#endif
