#include "utility.h"
#ifndef US316_H
#define US316_H
int totalOccupied(Coordinates coords[]);
#endif
