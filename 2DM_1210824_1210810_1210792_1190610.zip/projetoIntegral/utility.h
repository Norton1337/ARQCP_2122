#ifndef UTILITY_H
#define UTILITY_H

#define N_ELEM 4
#define N_MAX 5
#define SIZE 4

typedef struct {
	int x;
	int y;
	int z;
} Coordinates;

#endif
