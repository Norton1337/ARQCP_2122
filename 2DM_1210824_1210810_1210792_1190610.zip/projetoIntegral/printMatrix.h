#include "utility.h"
#ifndef PRINT_MATRIX_H
#define PRINT_MATRIX_H
void printMatrix(int matrix[N_MAX][N_MAX][N_MAX]);
#endif
