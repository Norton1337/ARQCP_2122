#ifndef DIVIDE_BY_COMMA_H
#define DIVIDE_BY_COMMA_H
int * divideByComma(char *pointer);
#endif
