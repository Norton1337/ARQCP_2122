#include "utility.h"
#ifndef PUT_REST_WITH_ZERO_H
#define PUT_REST_WITH_ZERO_H
void putRestWithZero(int matrixCopy[N_MAX][N_MAX][N_MAX]);
#endif
