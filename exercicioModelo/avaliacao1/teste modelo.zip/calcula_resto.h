#ifndef ASM_H
#define ASM_H
unsigned char calcula_resto();
extern unsigned short numero_atual;
#endif
