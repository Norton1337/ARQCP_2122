void noves_fora(unsigned int *numeros, int n);
