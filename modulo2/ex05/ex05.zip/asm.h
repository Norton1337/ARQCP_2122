#ifndef ASM_H
#define ASM_H
short swapBytes();
extern short op1;
#endif
