#ifndef ASM_H
#define ASM_H
int sum();
int sum_v2();
long sum_v3();
extern long op3;
extern long op4;
#endif
